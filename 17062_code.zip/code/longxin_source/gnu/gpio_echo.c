#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "gpio_echo.h"

#define BUFFER_MAX 3
#define DIRECTION_MAX 35
#define VALUE_MAX 30

int gpio_export(int gpio) {
    char buffer[BUFFER_MAX];
    ssize_t bytes_written;
    int fd;

    fd = open("/sys/class/gpio/export", O_WRONLY);
    if (fd == -1) {
        perror("gpio/export");
        return -1;
    }

    bytes_written = snprintf(buffer, BUFFER_MAX, "%d", gpio);
    write(fd, buffer, bytes_written);
    close(fd);

    return 0;
}

int gpio_unexport(int gpio) {
    char buffer[BUFFER_MAX];
    ssize_t bytes_written;
    int fd;

    fd = open("/sys/class/gpio/unexport", O_WRONLY);
    if (fd == -1) {
        perror("gpio/unexport");
        return -1;
    }

    bytes_written = snprintf(buffer, BUFFER_MAX, "%d", gpio);
    write(fd, buffer, bytes_written);
    close(fd);

    return 0;
}

int gpio_set_direction(int gpio, const char *direction) {
    char path[DIRECTION_MAX];
    int fd;

    snprintf(path, DIRECTION_MAX, "/sys/class/gpio/gpio%d/direction", gpio);
    fd = open(path, O_WRONLY);
    if (fd == -1) {
        perror("gpio/direction");
        return -1;
    }

    if (write(fd, direction, strlen(direction)) == -1) {
        perror("gpio/set-direction");
        close(fd);
        return -1;
    }

    close(fd);
    return 0;
}

int gpio_set_value(int gpio, int value) {
    char path[VALUE_MAX];
    int fd;

    snprintf(path, VALUE_MAX, "/sys/class/gpio/gpio%d/value", gpio);
    fd = open(path, O_WRONLY);
    if (fd == -1) {
        perror("gpio/set-value");
        return -1;
    }

    if (value == 0) {
        if (write(fd, "0", 1) != 1) {
            perror("gpio/write");
            close(fd);
            return -1;
        }
    } else {
        if (write(fd, "1", 1) != 1) {
            perror("gpio/write");
            close(fd);
            return -1;
        }
    }

    close(fd);
    return 0;
}

int gpio_get_value(int gpio, int *value) {
    char path[VALUE_MAX];
    char value_str[3];
    int fd;

    snprintf(path, VALUE_MAX, "/sys/class/gpio/gpio%d/value", gpio);
    fd = open(path, O_RDONLY);
    if (fd == -1) {
        perror("gpio/get-value");
        return -1;
    }

    if (read(fd, value_str, 3) == -1) {
        perror("gpio/read");
        close(fd);
        return -1;
    }

    close(fd);
    *value = atoi(value_str);
    return 0;
}

