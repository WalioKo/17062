#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "gpio_echo.h"
#include "Key_Board.h"

static int row_pins[] = ROW_PINS;
static int col_pins[] = COL_PINS;

// 初始化 GPIO
int key_board_init(void) {
    // 导出行和列的 GPIO 引脚
    for (int i = 0; i < 3; i++) {
        if (gpio_export(row_pins[i]) == -1 || gpio_export(col_pins[i]) == -1) {
            return -1;
        }
    }
    // 设置行 GPIO 为输出
    for (int i = 0; i < 3; i++) {
        if (gpio_set_direction(row_pins[i], "out") == -1) {
            return -1;
        }
    }
    // 设置列 GPIO 为输入
    for (int i = 0; i < 3; i++) {
        if (gpio_set_direction(col_pins[i], "in") == -1) {
            return -1;
        }
    }

    return 0;
}

// 扫描矩阵键盘，返回按下的按键值
int key_board_scan(void) {
    int value,row,r,col;
    for (row = 0; row < 3; row++) {
        // 设置当前行为低电平，其他行为高电平
        for (r = 0; r < 3; r++) {
            if(r == row){
                gpio_set_value(row_pins[r], 0);    
            }
            else{
                gpio_set_value(row_pins[r], 1);
            }
        }

        // 读取每一列的值
        for (col = 0; col < 3; col++) {
            if (gpio_get_value(col_pins[col], &value) == -1) {
                return -1;
            }
            if (value == 0) {
                return row * 3 + col; // 返回按键值
            }
        }
    }
    return -1; // 没有按键按下
}

// 取消导出 GPIO
void key_board_close(void) {
    for (int i = 0; i < 3; i++) {
        gpio_unexport(row_pins[i]);
        gpio_unexport(col_pins[i]);
    }
}
