#include "GnuShow.h"
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
void init_gnuplot(FILE *gnuplotPipe, float Freq, float Vpp) {
    fprintf(gnuplotPipe, "set terminal wxt size 1000,800 persist\n"); // ���ô��ڴ�СΪ 1024x768��������
    fprintf(gnuplotPipe, "set grid xtics ytics\n"); // ��ʾ����
    fprintf(gnuplotPipe, "set xlabel 'T'\n");
    fprintf(gnuplotPipe, "set ylabel 'V'\n");
    fprintf(gnuplotPipe, "set title 'Real-time Oscilloscope Interface'\n");

    // ��ʼ����ǩ
    fprintf(gnuplotPipe, "set label 1 'f: %f' at graph 0.05, 0.95\n", Freq);
    fprintf(gnuplotPipe, "set label 2 'Vpp: %.2f' at graph 0.45, 0.95\n", Vpp);
	fprintf(gnuplotPipe, "set label 3 'T: %.2f' at graph 0.85, 0.95\n", 1/Freq);
	 
    fflush(gnuplotPipe);
}

void plot_data(FILE *gnuplotPipe, const char *filename, double X_range, double Y_range, float Freq, float Vpp) {
    fprintf(gnuplotPipe, "set xrange [0:%lf]\n", X_range);
    fprintf(gnuplotPipe, "set yrange [%lf:%lf]\n", -Y_range, Y_range);

    // ��̬���� xtics �� ytics
    fprintf(gnuplotPipe, "set xtics %lf\n", X_range / 10.0);
    fprintf(gnuplotPipe, "set ytics %lf\n", Y_range / 4.0);
    
    // ����ɵı�ǩ
    fprintf(gnuplotPipe, "unset label 1\n");
    fprintf(gnuplotPipe, "unset label 2\n");
    fprintf(gnuplotPipe, "unset label 3\n");
    fprintf(gnuplotPipe, "unset label 4\n");
    fprintf(gnuplotPipe, "unset label 5\n");
    //fprintf(gnuplotPipe, "unset label 6\n");

    // �����µı�ǩ
    fprintf(gnuplotPipe, "set label 1 'f: %.2f/KHz' at graph 0.05, 0.95\n", Freq/1000);
    fprintf(gnuplotPipe, "set label 2 'Vpp: %.2f/V' at graph 0.35, 0.95\n", Vpp);
	fprintf(gnuplotPipe, "set label 3 'T/us: %.2f/us' at graph 0.65, 0.95\n", 1000000/(Freq));

    // �����½���ʾ��ǰ�� X_range �� Y_range
    char X_range_label[50], ymax_label[50];
    sprintf(X_range_label, "set label 4 '%.2fus/div' at graph 0.95, 0.05\n", 1000 * X_range / 10.0);
    sprintf(ymax_label, "set label 5 '%.2fV/div' at graph 0.95, 0.10\n", Y_range / 4.0);
    fprintf(gnuplotPipe, "%s", X_range_label);
    fprintf(gnuplotPipe, "%s", ymax_label);
     printf("%f\n",Freq);
    fprintf(gnuplotPipe, "plot '%s' using 2:1 with lines title ' '\n", filename);
    fflush(gnuplotPipe);
    usleep(500000);
  
}

