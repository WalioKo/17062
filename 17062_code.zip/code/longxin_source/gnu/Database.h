#ifndef DATABASE_H
#define DATABASE_H

void process_data(const char *filename, const char *db_filename, float *Freq, float *Vpp, float gain);
void Read_Database(const char *db_filename, const char *gnu_filename, float X_Time);

#endif // DATABASE_H

