#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "Database.h"
#include "GnuShow.h"
#include "uart.h"
#include "gpio_echo.h"
#include "Key_Board.h"

#define SERIAL_PORT "/dev/ttyUSB0"                                                                                                                 
#define OUTPUT_FILE "data.txt"
#define DATA_FILE "data.txt"
#define DATA_BASE "database.txt"
#define GNU_FILE   "gnudata.txt"

int main() {
	double X_range[4]={20.0,1,0.02,0.001};
    double Y_range[2]={0.4,4.0};
    int serial_fd;
	int key=1;
    float Freq = 0.0, Vpp = 0.0, T_fs = 0.0,gain=1;
    char Xnum = 1; // ��ʼ x ��ΧΪ 2us/div
    char Ynum = 1; // ��ʼ y ��ΧΪ 1V/div
    //��ʼ��
    FILE *fp = fopen(OUTPUT_FILE, "w");//�������ڽ����ļ�
    FILE *gnuplotPipe = popen("gnuplot -persist", "w");

    serial_fd = uart_open_and_init(SERIAL_PORT);
	key_board_init();
	init_gnuplot(gnuplotPipe, Freq, Vpp);

    char finish=0;

    // ��ʼ�� Gnuplot ���ں����� 
    while(1) {
        key = key_board_scan();

        printf("keynum:%d %f\n", key,X_range[Xnum]);
        switch(key){
            case 0: Xnum++;if(Xnum==4)Xnum=3;break;
            case 3: Xnum--;if(Xnum==-1)Xnum=0;break;
            case 1: Ynum++;if(Xnum==2)Xnum=1;break;
            case 4: Ynum--;if(Xnum==-1)Xnum=0;break;
            case 5: finish=1;break;
            default :break;
        }
        if(finish)break;
        uart_read_and_store(serial_fd);key = key_board_scan();
        // ��������
        process_data(DATA_FILE, DATA_BASE, &Freq, &Vpp, gain);
        // ��ȡ���ݿ��ļ�
        Read_Database(DATA_BASE, GNU_FILE, X_range[Xnum]);
		key = key_board_scan();
        // ������ʾ
        plot_data(gnuplotPipe, GNU_FILE, X_range[Xnum], Y_range[Xnum], Freq, Vpp);key = key_board_scan();
	}
    // �ر� Gnuplot ���ں�������Դ
    pclose(gnuplotPipe);
    return 0;
}

    
    

