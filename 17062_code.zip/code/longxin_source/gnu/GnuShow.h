#ifndef GNUSHOW_H
#define GNUSHOW_H

#include <stdio.h>

void init_gnuplot(FILE *gnuplotPipe, float Freq, float Vpp);
void plot_data(FILE *gnuplotPipe, const char *filename, double X_range, double Y_range, float Freq, float Vpp);

#endif /* GNUSHOW_H */

