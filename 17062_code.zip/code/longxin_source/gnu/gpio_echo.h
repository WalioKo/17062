#ifndef GPIO_ECHO_H
#define GPIO_ECHO_H

int gpio_export(int gpio);
int gpio_unexport(int gpio);
int gpio_set_direction(int gpio, const char *direction);
int gpio_set_value(int gpio, int value);
int gpio_get_value(int gpio, int *value);

#endif /* GPIO_echo_H */

