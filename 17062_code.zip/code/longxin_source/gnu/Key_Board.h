#ifndef KEY_BOARD_H
#define KEY_BOARD_H

// 定义行和列的 GPIO 引脚
#define ROW_PINS {40,56,58}
#define COL_PINS {60,2,3}

// 初始化矩阵键盘 GPIO
int key_board_init(void);

// 扫描矩阵键盘，返回按下的按键值
int key_board_scan(void);

// 取消导出 GPIO
void key_board_close(void);

#endif /* KEY_BOARD_H */
